#include <iostream>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <string>
#include <fstream>
#include <time.h>
#include "helper.h"
using std::cout;
using std::endl;
using std::cin;
using std::getline;
using std::ios;
using std::string;
using std::fstream;
using namespace std::chrono_literals;
using namespace std::this_thread;

int main()
{
	TableOfContents();
}