Binary File Exercise 2018
Made by Marcel Dao

For Monster Creature Quest:
ID numbers are formatted in 000. Enter numbers like 001, 002, 010, etc..
.bin file extension is appended by default for monster quest